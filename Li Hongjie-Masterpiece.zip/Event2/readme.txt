1. Please refer to Tableau workbook 'event2.twb'
2. PDF report included as 'CS5346 OTOT Task B - A0084237A- Masterpiece Recreation'